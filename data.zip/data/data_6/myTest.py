import numpy as np
import matplotlib.pyplot as plt
from process_data.uniformization import uniformization, reducePoint
from process_data.B_Spline_Approximation import BS_curve

def showTra(dataDir, reduce=False):
    tra = np.loadtxt("{}tra.csv".format(dataDir), delimiter=",", dtype="double")
    point = tra[130:, :2]
    if reduce:
        # point = reducePoint(point, step=50)
        point = uniformization(point, 5)
    point = point.T
    point[0, :] = point[0, :] - np.average(point[0, :])
    point[1, :] = point[1, :] - np.average(point[1, :])
    plt.scatter(point[0,:],point[1, :], color='r')
    plt.show()

# dir = "./data/bag_2/"
# showTra(dir, reduce=True)


def polyFitting(laneInfo):
    """
    使用多项式拟合轨迹
    degree: 多项式阶数
    """
    # 获取左边界线拟合参数
    boundary = uniformization(laneInfo[:, 2:4], 5)
    param = np.polyfit(boundary[:, 0], boundary[:, 1], 3)
    plt.scatter(boundary[:, 0], boundary[:, 1])
    x = boundary[:, 0]
    plt.plot(x, param[0]*x**3 + param[1]*x**2 + param[2]*x**1 + param[3], 'k--')
    plt.show()
    return param

def bsplineFitting(laneInfo, cpNum, degree, distance, show=False):
    """
    使用B样条拟合轨迹点
    """
    tra = laneInfo[:, 2:4]
    bs = BS_curve(cpNum, degree)
    # 获取左边界线拟合参数并简化轨迹点
    boundary = uniformization(tra, distance)
    # 打印边界点
    xx = boundary[: , 0]
    yy = boundary[: , 1]
    
    # print(boundary.shape)
    paras = bs.estimate_parameters(boundary)
    knots = bs.get_knots()
    if bs.check():
        cp = bs.approximation(boundary)
    uq = np.linspace(0,1,101)
    y = bs.bs(uq)
    if show:
        plt.scatter(xx ,yy)
        plt.plot(y[:,0],y[:,1],'r')
        plt.plot(cp[:,0],cp[:,1],'y')
        plt.scatter(cp[:,0],cp[:,1],c = 'y')
        plt.show()
    return cp


laneInfo = np.load("./data/bag_2/laneInfo.npy")
# polyFitting(laneInfo)
bsplineFitting(laneInfo=laneInfo, cpNum=8, degree=3, show=True, distance=5)